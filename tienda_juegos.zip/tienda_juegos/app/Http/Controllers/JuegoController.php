<?php

namespace App\Http\Controllers;

use App\Models\Juego;
use Illuminate\Http\Request;

class JuegoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $juegos=Juego::all(); //eloquent
        
        return view('juego.index',['juegos' => $juegos]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('juego.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
                //1º generar el objeto para guardar
        
        $object = new Juego($request->all());
        
        //2º intentar guardar
        //dd($object);
        try {
            
            $result = $object->save();  
        //3º si lo he guardado volver a algún sitio
            $afterInsert=session('afterInsert','show juegos');
            $target='juego';
            if($afterInsert != 'show juegos'){
                $target='juego/create';
            }
            return redirect($target)->with(['message'=> 'El juego ha sido creado.']);
            
        } catch(\Exception $e) {
            
        //4º si no lo he guardado, volver a la pag anterior con los datos para volver a rellenar el formulario
            return back()->withInput()->withErrors(['message' => 'El juego no ha sido creado.']);
            
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Juego  $juego
     * @return \Illuminate\Http\Response
     */
    public function show(Juego $juego)
    {
        return view('juego.show', ['juego' => $juego]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Juego  $juego
     * @return \Illuminate\Http\Response
     */
    public function edit(Juego $juego)
    {
        return view('juego.edit', ['juego' => $juego]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Juego  $juego
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Juego $juego)
    {
                        //1º generar el objeto para guardar
        
        
        try {
            
            $juego->update($request->all());
            $afterEdit=session('afterEdit','juego');
            $target='juego'; //edit/movie/show
            if($afterEdit=='juego'){
                $target='juego';
            }else if($afterEdit=='edit'){
                $target='juego/'.$juego->id .'/edit';
            }else{
                $target='juego/'.$juego->id;
            }
            //3º si lo he guardado volver a algún sitio
            return redirect($target)->with(['message'=> 'El juego ha sido actualizado.']);
            
        } catch(\Exception $e) {
            
            //4º si no lo he guardado, volver a la pag anterior con los datos para volver a rellenar el formulario
            return back()->withInput()->withErrors(['message' => 'El juego no ha sido actualizado.']);
            
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Juego  $juego
     * @return \Illuminate\Http\Response
     */
    public function destroy(Juego $juego)
    {
                try {
            $juego->delete();
            return redirect('juego')->with(['message' => 'El juego ha sido borrado.']);
        } catch(\Exception $e) {
             return back()->withErrors(['message' => 'El juego no ha sido borrado.']);
        } 
    }
    
            function view(Request $request, Juego $id){
        $juego=Juego::find($id);
        if($juego == null){
            return abort(404);
        }
        dd([$id,$juego]);
        
    }
}
