<?php $__env->startSection('title', 'Lista de videojuegos'); ?>

<?php $__env->startSection('content'); ?>

<div class="table-responsive small">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">nombre</th>
          <th scope="col">pais de origen</th>
          <th scope="col">año</th>
          <th scope="col">genero</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $juegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($juego->id); ?></td>
                <td><?php echo e($juego->name); ?></td>
                <td><?php echo e($juego->country); ?></td>
                <td><?php echo e($juego->year); ?></td>
                <td><?php echo e($juego->genre); ?></td>
                <td>
                    <a class="btn-primary btn" href="<?php echo e(url('juego/' . $juego->id)); ?>">mostrar</a>
                    <a class="btn-danger btn" href="<?php echo e(url('juego/' . $juego->id . '/edit')); ?>">editar</a>
                    <form data-juego="<?php echo e($juego->name); ?>" class="formDelete" action="<?php echo e(url('juego/' . $juego->id)); ?>" method="post" style="display: inline-block">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <button type="submit" class="btn btn-warning">borrar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <a class="btn-info btn" href="<?php echo e(url('juego/create')); ?>">crear</a>
</div>

<script>
  const forms = document.querySelectorAll(".formDelete");
  forms.forEach(function(form) {
      form.onsubmit = (event) => {
        return confirm('Seguro que quieres borrar ' + event.target.dataset.juego + '?');
      };
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda_juegos/resources/views/juego/index.blade.php ENDPATH**/ ?>