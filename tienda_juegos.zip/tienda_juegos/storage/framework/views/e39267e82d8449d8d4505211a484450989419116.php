<?php $__env->startSection('title','editar videojuego'); ?>

<?php $__env->startSection('content'); ?>



<form action="<?php echo e(url('juego/' . $juego->id)); ?>" method="post">

    <!-- Solución de error por CSRF -->
    <!--<input type="hidden" name="_method" value="put">-->
    <!--<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">-->
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>

    <!-- Inputs del formulario -->

    <div class="mb-3">

        <label for="name" class="form-label">Nombre del juego</label>

        <input type="text" class="form-control" id="name" name="name" maxlength="60" required value="<?php echo e(old('name', $juego->name)); ?>">

    </div>

    <div class="mb-3">

        <label for="country" class="form-label">Pais</label>

        <input type="text" class="form-control" id="country" name="country" maxlength="50" required value="<?php echo e(old('country', $juego->country)); ?>">

    </div>

    <div class="mb-3">

        <label for="year" class="form-label">Año</label>

        <input type="number" class="form-control" id="year" name="year" step="1" min="1" max="9999" required value="<?php echo e(old('year',$juego->year)); ?>">

    </div>

    <div class="mb-3">

        <label for="genre" class="form-label">Genero</label>

        <input type="text" class="form-control" id="genre" name="genre" maxlength="50" value="<?php echo e(old('genre', $juego->genre)); ?>">

    </div>

    <input type="submit" class="btn btn-success" value="Edit">


</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda_juegos/resources/views/juego/edit.blade.php ENDPATH**/ ?>