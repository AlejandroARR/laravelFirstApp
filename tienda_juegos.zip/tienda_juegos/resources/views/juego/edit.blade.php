@extends('app.base')

@section('title','editar videojuego')

@section('content')



<form action="{{ url('juego/' . $juego->id) }}" method="post">

    <!-- Solución de error por CSRF -->
    <!--<input type="hidden" name="_method" value="put">-->
    <!--<input type="hidden" name="_token" value="{{ csrf_token() }}">-->
    @method('put')
    @csrf

    <!-- Inputs del formulario -->

    <div class="mb-3">

        <label for="name" class="form-label">Nombre del juego</label>

        <input type="text" class="form-control" id="name" name="name" maxlength="60" required value="{{old('name', $juego->name) }}">

    </div>

    <div class="mb-3">

        <label for="country" class="form-label">Pais</label>

        <input type="text" class="form-control" id="country" name="country" maxlength="50" required value="{{old('country', $juego->country) }}">

    </div>

    <div class="mb-3">

        <label for="year" class="form-label">Año</label>

        <input type="number" class="form-control" id="year" name="year" step="1" min="1" max="9999" required value="{{old('year',$juego->year) }}">

    </div>

    <div class="mb-3">

        <label for="genre" class="form-label">Genero</label>

        <input type="text" class="form-control" id="genre" name="genre" maxlength="50" value="{{old('genre', $juego->genre) }}">

    </div>

    <input type="submit" class="btn btn-success" value="Edit">


</form>

@endsection